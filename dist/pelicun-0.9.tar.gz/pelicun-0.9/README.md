<img src="docs/figures/logo.PNG" alt="pelicun" height="100"/>

[![Documentation Status](https://readthedocs.org/projects/pelicun/badge/?version=latest)](http://pelicun.readthedocs.io/en/latest/?badge=latest)
[![TravisCI](https://travis-ci.org/zsarnoczay/pelicun.svg?branch=master)](https://travis-ci.org/zsarnoczay/pelicun)
[![Coverage Status](https://coveralls.io/repos/github/zsarnoczay/pelicun/badge.svg?branch=master)](https://coveralls.io/github/zsarnoczay/pelicun?branch=master)

Probabilistic Estimation of Losses, Injuries, and Community resilience Under Natural disasters

This package is in pre-alpha stage. Unless you are involved in the development, 
please check back a bit later.

## What is it?

Detailed documentation is available at http://pelicun.readthedocs.io

## What can I use it for?

## Why should I use it?

## Requirements

## Installation

```
pip install pelicun
```

## License

pelicun is distributed under the BSD 3-Clause license, see LICENSE.

## Contact

* Adam Zsarnóczay, NHERI SimCenter, Stanford University, adamzs@stanford.edu